import os
import rsa
import string
import random
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import cv2

def generate_key_and_iv(password, salt):
    # Derive a key and IV from the password and salt using PBKDF2
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32 + 16,  # 32 bytes for key and 16 bytes for IV
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    key_and_iv = kdf.derive(password)

    # Split the key and IV
    key = key_and_iv[:32]
    iv = key_and_iv[32:]

    return key, iv

def encrypt_file(input_file, output_image_file):
    # Generate a random password for encryption
    password = makeKey().encode()

    # Write the password to a text file
    with open('password.txt', 'w') as password_file:
        password_file.write(password.decode())

    # Generate a random salt
    salt = os.urandom(16)

    # Generate key and IV using the password and salt
    key, iv = generate_key_and_iv(password, salt)

    # Initialize AES cipher with CBC mode
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()

    # Read the contents of the input file
    with open(input_file, 'rb') as f:
        plaintext = f.read()

    # Apply PKCS7 padding to the plaintext
    padder = padding.PKCS7(128).padder()
    padded_plaintext = padder.update(plaintext) + padder.finalize()

    # Encrypt the padded plaintext
    ciphertext = encryptor.update(padded_plaintext) + encryptor.finalize()

    # Write the salt, IV, and ciphertext to the output image file
    with open(output_image_file, 'wb') as f:
        f.write(salt)
        f.write(iv)
        f.write(ciphertext)

    print("Encryption completed successfully!")

def makeKey():
    chars = string.ascii_letters + string.digits + string.punctuation + " "
    shuffled_chars = list(chars)
    while any(shuffled_chars[i] == chars[i] for i in range(len(chars))):
        random.shuffle(shuffled_chars)
    return ''.join(shuffled_chars)

# Example usage
input_file_path = "test.txt"  # Path to your input text file
output_image_path = 'output_image_with_hidden_encrypted_data.png'  # Path for the output image with hidden encrypted data

# Call the function to encrypt the contents of the input file and hide it in the image
encrypt_file(input_file_path, output_image_path)
