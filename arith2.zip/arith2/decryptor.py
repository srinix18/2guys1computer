import cv2
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

def decrypt_file(input_image_file, output_file):
    # Read the salt, IV, and ciphertext from the encrypted image file
    with open(input_image_file, 'rb') as f:
        # Read the salt (16 bytes)
        salt = f.read(16)
        # Read the IV (16 bytes)
        iv = f.read(16)
        # Read the ciphertext
        ciphertext = f.read()

    # Read the encryption key from the password.txt file
    with open("password.txt", 'r') as key_file:
        password = key_file.read().encode()

    # Derive the key using the password and salt
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    key = kdf.derive(password)

    # Initialize AES cipher with CBC mode
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()

    # Decrypt the ciphertext
    decrypted_data = decryptor.update(ciphertext) + decryptor.finalize()

    # Remove PKCS7 padding
    unpadder = padding.PKCS7(128).unpadder()
    unpadded_data = unpadder.update(decrypted_data) + unpadder.finalize()

    # Write the decrypted plaintext to the output file
    with open(output_file, 'wb') as f:
        f.write(unpadded_data)

    print("Decryption completed successfully!")

# Example usage
input_image_file = 'output_image_with_hidden_encrypted_data.png'  # Path to the image with hidden encrypted data
output_file_path = 'decrypted_output.txt'  # Path for the output decrypted file

# Call the decrypt function
decrypt_file(input_image_file, output_file_path)
